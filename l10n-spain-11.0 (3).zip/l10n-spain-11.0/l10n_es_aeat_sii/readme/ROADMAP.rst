* Comunicación de cobros y pagos.
* Determinadas facturas intracomunitarias (Articulo 66 RIVA).
* Facturas simplificadas.
* Asistente para consultar los documentos comunicados.
* Libro de bienes de inversión (Libro anual se crea un módulo aparte).
* Regímenes especiales de seguros y de agencias de viaje.
* Facturas rectificativas por sustitución.
