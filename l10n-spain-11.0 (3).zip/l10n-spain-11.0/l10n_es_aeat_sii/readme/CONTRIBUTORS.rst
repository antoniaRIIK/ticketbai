* Ignacio Ibeas <ignacio@acysos.com>
* Rubén Cerdà <ruben.cerda.roig@diagram.es>
* Ramon Guiu <ramon.guiu@minorisa.net>
* Pablo Fuentes <pablo@studio73.es>
* Jordi Tolsà <jordi@studio73.es>
* Ismael Calvo <ismael.calvo@factorlibre.es>
* Omar Castiñeira - Comunitea S.L. <omar@comunitea.com>
* Juanjo Algaz <jalgaz@gmail.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Javi Melendez <javimelex@gmail.com>
* Santi Argüeso - Comunitea S.L. <santi@comunitea.com>
* Angel Moya - PESOL <angel.moya@pesol.es>
* Eric Antonés - NuoBiT Solutions, S.L. <eantones@nuobit.com>
