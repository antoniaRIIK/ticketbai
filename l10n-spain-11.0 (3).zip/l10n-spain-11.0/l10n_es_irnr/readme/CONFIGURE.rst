Este addon añade los impuestos, códigos de impuestos y posiciones fiscales a
las siguientes plantillas:

* PGCE entidades sin ánimo de lucro 2008
* PGCE PYMEs 2008
* PGCE completo 2008

Para aplicar los cambios al plan contable que tengamos configurado en nuestra
compañía es posible que sea necesario instalar el addon
'OCA/account-financial-tools/account_chart_update' y actualizar:

* Impuestos
* Códigos de impuestos
* Posiciones fiscales
