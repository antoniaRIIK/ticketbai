* El apartado *II. Rentas no sometidas a retención / ingreso a cuenta*, no
  se rellena por el momento con ninguna base procedente de las ventas intra o
  extra comunitarias.
