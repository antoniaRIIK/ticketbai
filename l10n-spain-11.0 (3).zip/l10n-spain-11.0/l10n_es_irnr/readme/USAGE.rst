Las posiciones fiscales que nos añade este addon nos permiten:

* Como empresa que recibe una factura de un autónomo no residente (UE):

Asignar al autónomo la posición fiscal por ejemplo
'Retención IRPF No residentes UE 19%'. Por lo tanto, al crear una factura de
proveedor de ese autónomo se aplicará la retencion del 19% a todas las líneas
de la factura.

* Como autónomo no residente que emite una factura a todos sus clientes (UE):

Asignar a todos los clientes que tienen una posición fiscal 'Régimen Nacional'
la posición fiscal 'Retención IRPF No residentes UE 19%'. Por lo tanto,
al crear una factura a un cliente se aplique la retención del 19% a todas
las líneas de la factura.
