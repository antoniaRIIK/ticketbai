* Ainara Galdona <ainara.galdona@avanzosc.es>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Antonio Espinosa
  * Victor M.M. Torres

* Valentin Vinagre <valentin.vinagre@qubiq.es>
