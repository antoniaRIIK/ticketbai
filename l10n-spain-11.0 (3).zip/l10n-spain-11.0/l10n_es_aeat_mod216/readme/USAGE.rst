Para crear un modelo:

#. Ir a Contabilidad > Informe > Informes legales > Declaraciones AEAT > Modelo 216.
#. Pulsar en el botón "Crear".
#. Seleccionar el año y el tipo de período. Las fechas incluidas se calculan
   automáticamente.
#. Seleccionar el tipo de declaración.
#. Rellenar el teléfono de contacto, necesario para la exportacion BOE.
#. Guardar y pulsar en el botón "Calcular".
#. Rellenar (si es necesario) aquellos campos que Odoo no calcula automáticamente:

   * Rentas no sometidas a retención/ingreso a cuenta: [04] Nº de rentas y [05] Base de retenciones
   * Resultados a ingresar anteriores: [06]

#. Cuando los valores sean los correctos, pulsar en el botón "Confirmar"
#. Podemos exportar en formato BOE para presentarlo telemáticamente en el portal
   de la AEAT
