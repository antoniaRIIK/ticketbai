To use this module, you need to:

#. Go to a list of Partners, Contacts, Customer or Vendors and select one or more.
#. Press 'Action > Partner Activity Statement' or 'Action > Partner Outstanding Statement' respectively.
#. Indicate if you want to display receivables or payables, and if you want to display aging buckets and the aging type.
#. Optionally complete advanced options such as filtering non due or negative balance partners.
