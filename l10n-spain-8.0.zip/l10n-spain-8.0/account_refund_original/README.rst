Relationship between a refund and its original invoice
======================================================

This module links customer and supplier refunds with the invoice that originate
them.