# -*- coding: utf-8 -*-
# Copyright 2009 Zikzakmedia S.L. (http://zikzakmedia.com)
#                Jordi Esteve <jesteve@zikzakmedia.com>
# Copyright 2013 Joaquin Gutierrez (http://www.gutierrezweb.es)
# Copyright 2015 Tecnativa S.L. (http://www.tecnativa.com)
#                Pedro M. Baeza <pedro.baeza@tecnativa.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import report
from . import wizard
