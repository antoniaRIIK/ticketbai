Excel export for account balance reporting engine
=================================================

This module allows to export financial reports to XLS files from print dialog.

**WARNING:** This module requires module *report_xls*, available on:

  https://github.com/OCA/reporting-engine/

Contributors
------------
* Alejandro Santana <alejandrosantana@anubia.es>
* Juan Formoso <jfv@anubia.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com
