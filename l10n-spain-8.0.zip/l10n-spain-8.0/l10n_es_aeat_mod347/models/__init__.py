# -*- coding: utf-8 -*-

from . import account_period
from . import res_partner
from . import account_invoice
from . import mod347
