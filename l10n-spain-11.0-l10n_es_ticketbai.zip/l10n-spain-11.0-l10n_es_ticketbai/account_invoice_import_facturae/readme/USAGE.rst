To use this module, go to the menu *Accounting > Purchases > Import Invoice*
and upload a XSIG or XML invoice of your supplier.
