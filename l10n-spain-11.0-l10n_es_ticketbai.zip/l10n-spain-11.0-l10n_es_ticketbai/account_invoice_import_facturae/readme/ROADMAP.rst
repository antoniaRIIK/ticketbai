Although theoretically possible, the actual import has not yet been tested
with the following extensions:

* Extensión de FACeB2B

* CorreosExtension

