* `Studio73 <https://www.studio73.es/>`__:

  * Pablo Fuentes <pablo@studio73.es>
  * Jordi Tolsà <jordi@studio73.es>
* Omar Castiñeira - Comunitea S.L. <omar@comunitea.com>
* Angel Moya - PESOL <angel.moya@pesol.es>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Alexandre Díaz
  * Pedro M. Baeza
* Eric Antones - NuoBiT Solutions, S.L. <eantones@nuobit.com>
