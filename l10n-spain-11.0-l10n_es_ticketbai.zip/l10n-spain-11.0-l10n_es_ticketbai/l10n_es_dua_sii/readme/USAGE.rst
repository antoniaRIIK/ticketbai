Cuando se valida una factura se comprueba si se trata de una factura DUA
y se envía con los datos requeridos por la AEAT
