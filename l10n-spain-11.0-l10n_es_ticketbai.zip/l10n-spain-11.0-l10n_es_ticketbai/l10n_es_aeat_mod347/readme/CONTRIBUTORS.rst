* Pexego (http://www.pexego.es)
* ASR-OSS (http://www.asr-oss.com)
* NaN·tic (http://www.nan-tic.com)
* Acysos (http://www.acysos.com)
* Joaquín Gutierrez (http://gutierrezweb.es)
* Angel Moya <angel.moya@pesol.es>
* Albert Cabedo <albert@gafic.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Antonio Espinosa
  * Pedro M. Baeza
  * Cristina Martín
  * Carlos Dauden
