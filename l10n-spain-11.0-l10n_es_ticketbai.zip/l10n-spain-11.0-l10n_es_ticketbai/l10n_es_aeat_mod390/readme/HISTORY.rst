12.0.2.0.0 (2019-01-19)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] Añadido Diseño de registro dr390e2019v100 para declaración de 2019
