* Es necesario ir a los modos de pago e indicar su correspondencia con los
  códigos de Facturae.
* La dirección a la que se remite la factura de venta que queremos exportar
  debe estar marcada como facturae y debe tener cubiertos los datos de
  Oficina contable, Órgano gestor y Unidad tramitadora.
* Si se desea firmar el xml generado desde Odoo, tenemos que irnos al
  formulario de las compañías y subir el certificado en formato .pfx y
  escribir la contraseña de acceso al certificado.
* Actualizar los impuestos usando su clave Facturae
