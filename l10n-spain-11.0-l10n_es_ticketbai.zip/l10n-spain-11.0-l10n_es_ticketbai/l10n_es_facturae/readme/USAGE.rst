Desde el botón "Más" del formulario de factura, ejecutamos el asistente
denominado "Crear fichero Factura-E"
Podremos visualizar automáticamente campos extra de facturación electrónica si
el cliente es de facturación electrónica. Estos campos se podrán editar a nivel
de factura o de línea. En el caso de línea, aparecera un botón con un pop-up
con todo el detalle que podemos editar.
