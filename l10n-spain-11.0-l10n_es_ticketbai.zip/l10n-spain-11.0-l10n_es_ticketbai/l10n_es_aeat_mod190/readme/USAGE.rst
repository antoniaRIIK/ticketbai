
Para crear un modelo, por ejemplo de un año:

1. Ir a Facturación > Declaraciones AEAT > Modelo 190
2. Pulsar en el botón "Crear"
3. Seleccionar el ejercicio fiscal
4. Seleccionar el tipo de declaración
5. Se autorrellena el teléfono,el teléfono móvil y el correo electrónico del usuario, necesarios para la exportacion BOE
6. Guardar y pulsar en el botón "Calcular"
7. Rellenar aquellos campos que Odoo no calcula automáticamente:

   * Información relacionada con datos sensibles del perceptor solo en las claves A, B.01, B.03, C, E.01 y E.02

8. Cuando los valores sean los correctos, pulsar en el botón "Confirmar".
9. Podemos exportar en formato BOE para presentarlo telemáticamente en el portal
   de la AEAT


PENDIENTE:
- La información relativa a los perceptores, se ha añadido en una nueva pestaña en los terceros, queda pendiente del trato
que se le debe de dar a esta información ya es información sensible según la LOPD, de momento, sólo el
responsable de aeat, puede acceder a los datos.

- Se puede añadir un adjunto en los terceros donde se guarde el justificante del consentimiento expreso del tercero.


Antes de poder realizar el modelo, hay que introducir en los terceros, la información necesaria para el modelo.
