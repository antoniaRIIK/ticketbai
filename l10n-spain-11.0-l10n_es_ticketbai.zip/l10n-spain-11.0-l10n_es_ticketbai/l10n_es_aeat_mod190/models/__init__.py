from . import l10n_es_mod190_mixin
from . import l10n_es_mod190_additional_data_mixin
from . import res_partner
from . import l10n_es_aeat_mod190_report
from . import l10n_es_aeat_perception
from . import account_move_line
from . import account_invoice
from . import account_fiscal_position
