Modelo 296 de la AEAT. Declaración Informativa. Retenciones e ingresos a
cuenta del Impuesto sobre la Renta de no Residentes (sin establecimiento
permanente). Resumen anual.
