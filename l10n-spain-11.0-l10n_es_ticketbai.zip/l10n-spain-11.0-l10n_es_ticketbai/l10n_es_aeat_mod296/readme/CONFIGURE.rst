Debemos indicar los proveedores que son no residentes, en la ficha de la
empresa: Contabilidad > Proveedores > Proveedores, pestaña de Contabilidad.
El campo "Es no residente" tiene que estar marcado para que las retenciones
realizadas a este proveedor se incluyan en el modelo 296.
