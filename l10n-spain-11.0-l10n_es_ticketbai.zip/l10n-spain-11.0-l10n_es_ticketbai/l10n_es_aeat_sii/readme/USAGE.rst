Cuando se valida una factura automáticamente envia la comunicación al servidor
de AEAT.
