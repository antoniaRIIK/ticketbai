**AVISO**: Este modelo no cubre el 100% de las posibilidades que se pueden
dar en la declaración, por lo que se exime a los desarrolladores de cualquier
responsabilidad derivada de su uso. Carencias conocidas:

* La casilla [02] no se calculará correctamente si se incluyen en la partida
  de gastos (familia de cuentas 6), gastos que no son deducibles.
* No se controla el límite máximo de 2000 € en los gastos no deducibles de
  difícil justificación.
* En la casilla [04], no se tienen en cuenta deducciones para rentas obtenidas
  en Ceuta o Melilla.
* No se tienen en cuenta las retenciones e ingresos a cuenta soportados sobre
  los rendimientos procedentes de las actividades económicas (casilla [06]).
* No se pueden realizar declaraciones para actividades agrícolas, ganaderas,
  forestales y pesqueras (casillas [08] a [11]).
* No se pueden aplicar las deducciones correspondientes por el artículo 80 bis
  (casilla [13]).
* No se pueden deducir resultados negativos de anteriores declaraciones
  (casilla [15]).
