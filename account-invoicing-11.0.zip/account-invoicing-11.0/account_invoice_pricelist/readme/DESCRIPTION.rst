* Add a stored field pricelist on invoices, related to the partner pricelist;
* Use this pricelist when manually adding invoice lines
* Possibility to group by pricelist on account.invoice view;

.. image:: static/src/description/screenshot_group_by.png

For further information, please visit:

* https://www.odoo.com/forum/help-1