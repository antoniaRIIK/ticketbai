* Eficent <http://www.eficent.com>:

  * Jordi Ballester Alomar <jordi.ballester@eficent.com>

* Tecnativa <https://www.tecnativa.com>

  * Pedro M. Baeza
