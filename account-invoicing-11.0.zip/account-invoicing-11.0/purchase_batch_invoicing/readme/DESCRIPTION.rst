This module extends the functionality of purchases to support batch invoicing
purchase orders and to allow you to choose if you want them grouped by purchase
order or by vendor.
