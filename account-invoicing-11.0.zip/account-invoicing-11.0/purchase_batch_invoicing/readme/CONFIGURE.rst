An automated task is included to invoice all pending purchase orders every
week, but it is disabled by default. To enable it:

#. Have *Administration / Settings* permissions.
#. Go to *[Your user menu] > About > Activate the developer mode*.
#. Go to *Settings > Technical > Automation > Scheduled Actions > Invoice all
   pending purchase orders > Edit*.
#. Enable it by clicking on *Active* and set the date accordingly.
#. Save.

To use this module, you'll need:

#. Have *Purchase / User* permissions.
