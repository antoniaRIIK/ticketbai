* This module doesn't take into account any possible modification on grouping
  criteria, like all the modules that use
  ``sale_order_action_invoice_create_hook``.
