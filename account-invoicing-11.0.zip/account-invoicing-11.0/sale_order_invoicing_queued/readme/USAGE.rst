#. Go to *Sales > Invoicing > Orders to Invoice*.
#. Select sales orders whose invoicing you want to enqueue.
#. Click on *Action > Invoice Order*.
#. Click on "Enqueue Invoicing" button.
#. On that moment, jobs will be enqueued on foreground, but the control will
   be returned to you after that.
#. Having the "Job Queue Manager" permissions, you can go to the sales order,
   and see the tab "Invoicing Jobs". There a list with all the jobs related
   to that sales order can be found.
