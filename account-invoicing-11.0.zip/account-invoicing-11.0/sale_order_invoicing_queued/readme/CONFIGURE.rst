Jobs are enqueued in the channel ``root.sale_order_invoicing_queued``,
so you must adjust your Odoo configuration according this.

If you want to see queued jobs, you need "Job Queue / Job Queue Manager"
permission in your user.
