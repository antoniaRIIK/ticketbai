#. This module requires the additional installation of sale_stock or purchase
   modules for enabling the features it contains.
