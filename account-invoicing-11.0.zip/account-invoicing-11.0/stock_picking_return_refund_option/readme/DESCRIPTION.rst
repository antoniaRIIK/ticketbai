This module extends the functionality of sales and purchase orders to support
modify stock move field to_refund after it has been confirmed.
