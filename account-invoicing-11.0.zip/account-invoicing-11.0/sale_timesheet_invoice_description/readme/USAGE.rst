To use this module, you need to:

#. Go to *Sales -> Catalog -> Products* and create a new Product with:

   - *Product Type* -> **Service**
   - *Service Invoicing Policy* -> **Timesheets on tasks**
   - *Service Tracking* -> **Create a new project but no task**
#. Go to *Sales -> Orders -> Orders* and create a new Sale Order.
#. Add line selecting the product
#. Confirm Sale
#. Go to *Timesheets -> Timesheet -> My Timesheets* and create line with same
   project of SO and the related task
#. Go to the Sale Order and select *Other Information* -> **Timesheet invoice
   description**
#. *Create Invoice*
