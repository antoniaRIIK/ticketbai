#. Go to *Sales > Invoicing > Orders to Invoice*.
#. Select sales orders whose invoicing you want to do.
#. Click on *Action > Invoice Order*.
#. Click on "Create and View Invoices" button.
#. On that moment, the grouping criteria will be applied, and you will see
   different invoices if the criteria doesn't match for them.
