This module allows to use custom criteria for grouping sales orders to be
invoiced.

Default criteria for grouping (invoicing partner and currency used) will be
always applied, as if not respected, there will be business inconsistencies,
but you can add more fields to split the invoicing according them.
