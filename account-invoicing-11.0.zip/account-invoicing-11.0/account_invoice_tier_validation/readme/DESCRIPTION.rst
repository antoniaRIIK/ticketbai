This module extends the functionality of Invoices to support a tier
validation process.
