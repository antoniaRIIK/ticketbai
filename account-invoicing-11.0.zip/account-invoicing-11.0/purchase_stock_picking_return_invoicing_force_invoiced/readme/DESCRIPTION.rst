This module forces the status of the purchase order to remain in 'Invoiced'
even when you have returned items into stock, if you indicated in the purchase
order that you wanted to force the invoiced status.

It is a glue module between the module 'Purchase Force Invoiced' and
'Purchase Stock Picking Return Invoicing'.
