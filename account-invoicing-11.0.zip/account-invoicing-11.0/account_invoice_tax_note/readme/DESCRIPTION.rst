In some situations, a mention must be displayed on invoices when a specific tax is used.
This module lets you define such a mention on Tax Groups.
This mechanism complements the invoice note coming from the fiscal position.
These tax group notes are translatable and company dependent.
To contribute to this module, please visit https://odoo-community.org.