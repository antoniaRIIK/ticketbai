
The exchange rate will be configured in
Accounting > Configuration > Multi-Currencies > Currencies
