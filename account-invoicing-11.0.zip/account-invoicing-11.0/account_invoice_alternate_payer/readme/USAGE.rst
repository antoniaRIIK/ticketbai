Access to the invoice and change the Alternate Payor/Payee of the invoice.
