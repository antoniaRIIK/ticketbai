This module allows to enter an alternative payer in the
customer invoice or vendor bill.

This allows, that we pay or expect to get paid by another partner other
than the main partner.
