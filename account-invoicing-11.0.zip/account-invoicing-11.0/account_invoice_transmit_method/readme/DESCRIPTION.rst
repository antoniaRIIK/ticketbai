This module allows to configure an *Invoice Transmit Method* on each partner. This module provides by default 3 transmission methods:

* E-mail
* Post
* Customer Portal

You can manually create additional transmission methods or other modules can create additional transmission methods (for example, the module *l10n_fr_chorus* creates a specific transmission method *Chorus*, which is the e-invoicing platform of the French administration).
