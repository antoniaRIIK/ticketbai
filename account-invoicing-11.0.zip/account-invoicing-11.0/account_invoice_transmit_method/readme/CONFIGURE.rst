If you need to add Transmit Methods, go to the menu *Invoicing > Configuration > Management > Transmit Methods*.
