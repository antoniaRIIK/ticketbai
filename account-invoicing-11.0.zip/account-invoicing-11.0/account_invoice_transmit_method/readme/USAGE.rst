On the form view of a parent Partner (not a Contact), in the *Accounting* tab, there are 2 fields:

* Customer Invoice Transmission Method
* Vendor Invoice Reception Method

When you create an invoice, this value is automatically copied on the invoice (and can be modified).
