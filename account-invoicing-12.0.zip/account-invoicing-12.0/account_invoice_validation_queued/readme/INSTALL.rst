This module depends on *queue_job* module that is hosted on
https://github.com/OCA/queue.
