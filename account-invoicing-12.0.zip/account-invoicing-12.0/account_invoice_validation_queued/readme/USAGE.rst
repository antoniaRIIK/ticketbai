#. Go to *Invoicing > Sales > Documents > Customer Invoices* or
   *Invoicing > Purchases > Documents > Vendor Bills*.
#. Mark at least one check on the left part of one draft invoice line in the
   list view.
#. Click on *Action > Confirm Draft Invoice*.
#. On the dialog popup that appears, click on "Enqueue Validation".
#. If any of the selected invoices are not in draft state, you will receive
   an error.
#. If any of the invoices is already enqueued, there will be a message saying
   so and avoiding to perform the process.
#. Once enqueued, and having the "Job Queue Manager" permission, you can go to
   the invoice, and see the tab "Validation Jobs". A list with all the jobs
   related to that invoice can be found there.
