Only users assigned to the group "Billing" can display the payments from the
invoice.
