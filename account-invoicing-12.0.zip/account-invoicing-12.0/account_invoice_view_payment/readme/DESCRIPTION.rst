This module allows users to access directly to the payment from an invoice
when registering a payment or afterwards.

The option to open the payment when it's being registered is useful
when the user needs to do a follow-up step on the payment, such as printing
the associated check.
