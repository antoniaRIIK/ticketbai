This module adds a link between invoices and repair orders. Invoices are generated from
the repair orders. With this module you can navigate back to the repair orders that
generated a specific invoice.

This module is useful if you want to add information from the repair in the invoice report.
