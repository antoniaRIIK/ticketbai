If you need to add Transmit Methods, go to the menu *Invoicing / Accounting > Configuration > Management > Transmit Methods*.
