* Alexis de Lattre <alexis.delattre@akretion.com>
* Shine IT <contact@openerp.cn>
