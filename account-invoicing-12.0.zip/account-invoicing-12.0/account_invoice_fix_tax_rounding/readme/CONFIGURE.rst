Go to Accounting Configuration and adjust the maximum amount of tax difference
that will be automatically fixed in invoices.

This is a 'double security' check as this argument has long been discussed with
Odoo without a solution.
