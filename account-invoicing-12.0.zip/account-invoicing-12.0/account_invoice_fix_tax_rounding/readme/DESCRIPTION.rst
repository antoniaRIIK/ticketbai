Fix amount of taxes computed on invoice when using global rounding
