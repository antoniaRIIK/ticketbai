In order for this module to work correctly please ensure to set an
Expense / Cost of Goods Sold as output account in the product category.
