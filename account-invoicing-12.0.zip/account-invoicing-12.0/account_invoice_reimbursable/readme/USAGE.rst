#. Go to 'Accounting/Invoicing > Vendors > Bills'
#. Create an invoice for a provider and add the reimbursables on the
   reimbursable page
#. Validate the invoice
