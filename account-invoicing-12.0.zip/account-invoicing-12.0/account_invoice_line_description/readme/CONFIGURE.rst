The setting *Use only product description on invoice lines* needs to be checked.
This can be done in these following ways:

* on the Access Rights (Technical Settings) of the user
* on the Invoicing Settings inside of the section `Invoices`