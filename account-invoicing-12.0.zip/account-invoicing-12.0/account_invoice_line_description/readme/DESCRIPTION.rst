This module allows to use only the sale description or the purchase description
on the invoice lines depending on the invoice type.