Organizations often require to quickly find the invoices associated to a
project or to an analytic account, searching by it's code or name.
This module introduces the possibility search customer or supplier
invoices by analytic account.
