To use this module, you need to:

#. Go to Accounting > Configuration > Management > Transmit Method Substitution Rules
#. Create a transmit substitution rule
    * Add a domain to indicate when the substitution must happen
    * Add a transmit method that will be set if an invoice match the domain at creation
