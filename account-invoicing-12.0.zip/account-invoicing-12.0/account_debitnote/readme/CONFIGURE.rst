To configure this module, you need to:

- Make sure user has access to "Show Full Accounting Features".
- Invoicing -> Configuration -> Journals -> Customer Invoices/Vendor Bills
    -> check Dedicated Debit Note Sequence.
