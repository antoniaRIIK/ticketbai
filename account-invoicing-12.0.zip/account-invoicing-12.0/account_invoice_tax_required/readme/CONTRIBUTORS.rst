* Vincent Renaville <vincent.renaville@camptocamp.com>
* Angel Moya <odoo@tecnativa.com>
* Kitti U. <kittiu@ecosoft.co.th>
* Jorge Camacho <jcamacho@trey.es>
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* Juan Vicente Pascual <jvpascual@puntsistemes.es>
