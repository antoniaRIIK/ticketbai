In a open validated invoice, click on 'Add Credit Note' to open the refunding wizard. Select the
'Refund specific lines' option and select the desired invoice lines.
