* Chafique Delli <chafique.delli@akretion.com>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
* Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>
* Stefan Rijnhart <stefan@opener.amsterdam>
