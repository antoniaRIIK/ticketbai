This module allows to automatically update all products information in vendor bill for which the purchase information on the line are different from the supplier information defined in the product form.

It creates a new supplier information line if there is not any or it updates the first one in the list.
