* Go to *Accounting > Customers > Invoices* (or *Accounting > Vendors > Bills*)
* Select an open invoice
* Click on "Add Credit Note"
* In the wizard, select the reason and add the credit note
* In the pivot view, group customer invoices by Reason
