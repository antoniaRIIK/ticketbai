This module allows you to define a list of reasons to create a credit note from
a customer invoice or vendor bill and report on them.
