* Go to *Accounting > Configuration > Management > Refund Reasons*
* Review the list of predefined reasons to update them or add new ones
