#. Go to 'Accounting/Invoicing > Configuration > Taxes';
#. Select a tax and click on the 'Tax Group' field;
#. Edit the note of the Tax Group.
