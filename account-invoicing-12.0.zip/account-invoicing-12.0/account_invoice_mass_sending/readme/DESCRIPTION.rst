This module adds a mass sending feature on invoices, using asynchronous jobs.
