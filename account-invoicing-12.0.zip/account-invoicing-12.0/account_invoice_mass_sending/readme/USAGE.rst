On the invoices list view, select the invoices to send and click on 'Action > Send & print'.

It will use the existing 'SEND & PRINT' action on the invoice with the default value.
