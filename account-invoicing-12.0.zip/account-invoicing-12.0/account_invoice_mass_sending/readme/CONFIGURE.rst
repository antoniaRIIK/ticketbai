Two channel are available for queue job:

* root.PREPARE_SEND_PRINT_INVOICE: jobs which will create sending jobs (with the following channel)
* root.SEND_PRINT_INVOICE: jobs which will send the mail
