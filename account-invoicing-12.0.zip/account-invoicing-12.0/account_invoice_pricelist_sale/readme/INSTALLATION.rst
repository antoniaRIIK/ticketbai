Module is automatically installed when both ``account_invoice_pricelist`` and
``sale`` modules are installed.
