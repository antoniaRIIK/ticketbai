This module extend the 'Account Invoice Pricelist' and 'Sale' modules
and Copies pricelist from sales order to invoice.s
