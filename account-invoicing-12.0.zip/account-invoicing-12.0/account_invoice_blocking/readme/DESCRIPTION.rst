This module allows the user to set a blocking (No Follow-up) flag directly on the invoice. This facilitates the blocking of the invoice's move lines.
