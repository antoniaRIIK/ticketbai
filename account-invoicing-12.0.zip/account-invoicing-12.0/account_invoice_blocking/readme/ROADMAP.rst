Future possible improvement :
Blocking invoice can also mean "do not send overdue reminders", so the blocking flag could be displayed on both supplier and customer invoices.
