You can set the No Follow-up flag on invoices.
