With this module, when a user changes the fiscal position of an invoice, the
taxes and the accounts on all the invoice lines which have a product are
automatically updated. The invoice lines without a product are not updated and
a warning is displayed to the user in this case.
