Provides a new sequence field on invoice lines which helps to manage the order of the invoice lines.
