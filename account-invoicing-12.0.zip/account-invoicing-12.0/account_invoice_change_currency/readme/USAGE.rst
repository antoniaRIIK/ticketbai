To use this module, the user must be in group Accounting & Finance / Adviser
to be able to update currency of Invoices
