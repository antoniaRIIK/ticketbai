This module move accounting date of supplier invoice near invoice date, to be
more visible to accounting user.
