Add a Verification Total field on vendor bills.

The user enters the taxes included invoice total as printed on the vendor bill,
then enters the invoice lines and taxes.

The system then checks the total computed by Odoo is the same as the verification total.
