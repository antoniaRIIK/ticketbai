The user has to belong to the *Allow "Invoice Force Number"* group.
This can be done as follows:

* checking the corresponding setting on the Access Rights (Technical Settings) of the user
* manually adding it to the corresponding group