* Alex Comba <alex.comba@agilebg.com> (https://www.agilebg.com/)
* Francesco Apruzzese <f.apruzzese@apuliasoftware.it>