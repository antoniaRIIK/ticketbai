[![Runbot Status](http://runbot.adhoc.com.ar/runbot/badge/flat/16/13.0.svg)](http://runbot.adhoc.com.ar/runbot/repo/github-com-ingadhoc-account-invoicing-16)
[![Build Status](https://travis-ci.org/ingadhoc/account-invoicing.svg?branch=13.0)](https://travis-ci.org/ingadhoc/account-invoicing)
[![Coverage Status](https://coveralls.io/repos/ingadhoc/account-invoicing/badge.png?branch=13.0)](https://coveralls.io/r/ingadhoc/account-invoicing?branch=13.0)
[![Code Climate](https://codeclimate.com/github/ingadhoc/account-invoicing/badges/gpa.svg)](https://codeclimate.com/github/ingadhoc/account-invoicing)

# ADHOC Account Invoicing

Odoo Invoicing Extension Addons

[//]: # (addons)
[//]: # (end addons)

Translation Status
------------------
[![Transifex Status](https://www.transifex.com/projects/p/ingadhoc-account-invoicing-13-0/chart/image_png)](https://www.transifex.com/projects/p/ingadhoc-account-invoicing-13-0)

----

<img alt="ADHOC" src="http://fotos.subefotos.com/83fed853c1e15a8023b86b2b22d6145bo.png" />
**Adhoc SA** - www.adhoc.com.ar
