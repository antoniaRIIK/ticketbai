This module adds the 'Date Range' field to the Odoo CE standard addons
financial reports wizard.
