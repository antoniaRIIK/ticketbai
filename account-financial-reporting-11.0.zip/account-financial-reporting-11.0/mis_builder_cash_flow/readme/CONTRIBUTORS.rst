* Juan José Scarafía <jjs@adhoc.com.ar>
* Gonzalo Ruzafa <gr@adhoc.com.ar>
* Enric Tobella <etobella@creublanca.es>
